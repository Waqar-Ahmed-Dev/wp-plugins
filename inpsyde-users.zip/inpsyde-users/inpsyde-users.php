<?php
global $wpdb;
//print_r($wpdb);

?>
<h2>Welcome to Insyde Users List Management</h2>
Admin setting for the plugin will go on this page.